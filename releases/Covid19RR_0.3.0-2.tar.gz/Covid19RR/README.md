# Covid19RR
Estimation of reproduction rates for the COVID-19 pandemic in Denmark based on publicly available data

## TODO

- Fix issue with Roxygen / .onAttach
- Remove hard-coded settings
- Clean up package dependencies
- Implement plot as a method
- General tidyup of R code
- Improve documentation
- Write vignette
- Pass R CMD check
