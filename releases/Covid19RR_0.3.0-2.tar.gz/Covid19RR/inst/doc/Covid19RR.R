## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library("Covid19RR")

## -----------------------------------------------------------------------------
dat <- download_data()
mod <- estimate_cv19rr(dat)

## -----------------------------------------------------------------------------
# TODO: set height/width to avoid error about figure margins
# plot(mod)

