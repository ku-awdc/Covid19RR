library(testthat)
library(Covid19RR)

test_check("Covid19RR")
