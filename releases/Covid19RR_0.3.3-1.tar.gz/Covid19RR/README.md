# Covid19RR
Estimation of reproduction rates for the COVID-19 pandemic in Denmark based on publicly available data

## TODO

- Improve documentation
- Write vignette
- Print and autoplot methods
- Write tests
